<?php
/**
 * Accès aux données utilisateur — code legacy.
 * Ce fichier est inclus par connexion.php : il doit donc être
 * migré AVANT lui (dépendance du projet).
 */
function recupererUtilisateur($email) {

    // Invariant : l'adresse doit être plausible
    if (strlen($email) < 5) {
        throw new Exception('Adresse invalide');
    }

    // VULNERABILITE : concatenation directe (CWE-89)
    $sql = "SELECT * FROM utilisateurs WHERE email='" . $email . "'";
    $resultat = mysql_query($sql);

    return mysql_fetch_array($resultat);
}
