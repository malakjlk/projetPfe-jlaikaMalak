<?php
/**
 * Connexion d'un utilisateur — code legacy.
 * Dépend de bd.php pour la récupération des données.
 */
include('bd.php');

function connecter($email, $motdepasse) {

    // Invariant 1 : longueur minimale du mot de passe
    if (strlen($motdepasse) < 8) {
        throw new Exception('Mot de passe trop court');
    }

    // Invariant 2 : format de l'adresse
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception('Adresse invalide');
    }

    $utilisateur = recupererUtilisateur($email);

    return $utilisateur["id"];
}
