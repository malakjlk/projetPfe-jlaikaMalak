<?php
class Utilisateur {
    protected $nom;
    protected $email;
    public function obtenirNom() {
        return $this->nom;
    }
    public function definirEmail($email) {
        if (strlen($email) < 5) {
            throw new Exception("Email trop court");
        }
        $this->email = $email;
    }
}
