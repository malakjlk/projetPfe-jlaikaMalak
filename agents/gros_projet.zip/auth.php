<?php
include "securite.php";
function authentifier($email, $mdp) {
    Validateur::validerEmail($email);
    Validateur::validerMotDePasse($mdp);
    return true;
}
function deconnecter($session) {
    if (empty($session)) {
        throw new Exception("Session vide");
    }
    return true;
}
