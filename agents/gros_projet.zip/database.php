<?php
include "config.php";
function connecterDB() {
    $host = chargerConfig("db_host");
    $conn = mysqli_connect($host, "root", "", "app");
    return $conn;
}
function requeteUtilisateur($id) {
    $conn = connecterDB();
    $sql = "SELECT * FROM users WHERE id=" . $id;
    return mysqli_query($conn, $sql);
}
