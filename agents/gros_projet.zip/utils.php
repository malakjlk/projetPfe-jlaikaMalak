<?php
class Outils {
    public static function nettoyer($texte) {
        return htmlspecialchars($texte);
    }
    public static function tronquer($texte, $longueur) {
        if ($longueur < 1) {
            throw new Exception("Longueur invalide");
        }
        return substr($texte, 0, $longueur);
    }
}
