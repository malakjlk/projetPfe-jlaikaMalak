<?php
function chargerConfig($cle) {
    if (!isset($cle)) {
        throw new Exception("Clé manquante");
    }
    $config = array("db_host" => "localhost", "db_name" => "app");
    return $config[$cle];
}
