<?php
include "utilisateur.php";
class Administrateur extends Utilisateur {
    private $niveau;
    public function supprimerCompte($id) {
        if (!is_numeric($id)) {
            throw new Exception("ID invalide");
        }
        return true;
    }
}
