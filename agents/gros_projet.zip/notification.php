<?php
function envoyerEmail($destinataire, $message) {
    if (strlen($destinataire) < 5) {
        throw new Exception("Destinataire invalide");
    }
    return true;
}
function envoyerSMS($numero, $texte) {
    if (!is_numeric($numero)) {
        throw new Exception("Numero invalide");
    }
    return true;
}
