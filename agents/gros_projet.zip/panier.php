<?php
class Panier {
    private $articles;
    private $total;
    public function ajouter($nom, $prix) {
        if ($prix < 0) {
            throw new Exception("Prix negatif");
        }
        $this->total += $prix;
    }
    public function total() {
        return $this->total;
    }
}
