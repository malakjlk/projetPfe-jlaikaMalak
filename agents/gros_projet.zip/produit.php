<?php
class Produit {
    private $nom;
    private $prix;
    public function definirPrix($prix) {
        if ($prix < 0) {
            throw new Exception("Prix invalide");
        }
        $this->prix = $prix;
    }
    public function obtenirPrix() {
        return $this->prix;
    }
}
