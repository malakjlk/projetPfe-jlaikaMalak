<?php
class Validateur {
    public static function validerEmail($email) {
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new Exception("Email invalide");
        }
        return true;
    }
    public static function validerMotDePasse($mdp) {
        if (strlen($mdp) < 8) {
            throw new Exception("Mot de passe trop court");
        }
        return true;
    }
}
