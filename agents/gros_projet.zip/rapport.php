<?php
class GenerateurRapport {
    public static function generer($commande) {
        $sortie = shell_exec("echo " . $commande);
        return $sortie;
    }
    public static function formater($montant) {
        if (!is_numeric($montant)) {
            throw new Exception("Montant invalide");
        }
        return number_format($montant, 2);
    }
}
