<?php
include "panier.php";
include "database.php";
function creerCommande($donnees) {
    if (!isset($donnees)) {
        throw new Exception("Donnees manquantes");
    }
    $obj = unserialize($donnees);
    return $obj;
}
